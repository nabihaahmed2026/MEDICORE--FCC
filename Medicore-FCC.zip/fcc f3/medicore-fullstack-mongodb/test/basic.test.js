const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
test('project uses MongoDB/Mongoose, not MySQL', () => {
  const pkg = require(path.join(root, 'package.json'));
  assert.ok(pkg.dependencies.mongoose);
  assert.equal(pkg.dependencies.mysql2, undefined);
});
test('login UI and authenticated data forms are present', () => {
  const html = fs.readFileSync(path.join(root, 'public/index.html'), 'utf8');
  assert.ok(html.includes('id="loginForm"'));
  assert.ok(html.includes('id="appScreen" class="app-screen hidden"'));
  assert.ok(html.includes('id="patientForm"'));
  assert.ok(html.includes('id="appointmentForm"'));
});
test('server protects data APIs and connects to MongoDB', () => {
  const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
  assert.ok(server.includes('mongoose.connect'));
  assert.ok(server.includes("app.get('/api/patients', loggedIn"));
  assert.ok(server.includes("app.post('/api/patients', loggedIn"));
  assert.ok(server.includes("app.post('/api/appointments', loggedIn"));
});

test('requested MediCore modules and MongoDB collections are included', () => {
  const html = fs.readFileSync(path.join(root, 'public/index.html'), 'utf8');
  const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
  for (const id of ['staffView', 'prescriptionsView', 'reportsView', 'notificationsView']) assert.ok(html.includes(id));
  for (const route of ["app.get('/api/staff'", "app.get('/api/prescriptions'", "app.get('/api/notifications'", "app.get('/api/backup'", "app.get('/api/reports/summary'"]) assert.ok(server.includes(route));
  assert.ok(server.includes('model.createCollection()'));
});
test('UI requires sign-in again on page reload', () => {
  const js = fs.readFileSync(path.join(root, 'public/app.js'), 'utf8');
  assert.ok(js.includes("await api('/api/logout',{method:'POST',body:'{}'})"));
});

test('Node syllabus demos are included', () => {
  const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
  assert.ok(server.includes("require('node:events')"));
  assert.ok(server.includes("require('node:url')"));
  assert.ok(server.includes("app.post('/api/uploads'"));
  assert.ok(fs.existsSync(path.join(root, 'scripts/send-email.js')));
  assert.ok(fs.existsSync(path.join(root, 'docs/SYLLABUS_CONCEPT_MAPPING.md')));
});
