
require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const path = require('node:path');
const fs = require('node:fs');
const { EventEmitter } = require('node:events');
const multer = require('multer');
const { randomUUID } = require('node:crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);

const logDir = path.join(__dirname, 'logs');
const uploadDir = path.join(__dirname, 'uploads');

fs.mkdirSync(uploadDir, { recursive: true });
fs.mkdirSync(logDir, { recursive: true });

const hospitalEvents = new EventEmitter();

function audit(event, data = {}) {
  fs.appendFile(
    path.join(logDir, 'activity.log'),
    JSON.stringify({
      at: new Date().toISOString(),
      event,
      data
    }) + '\n',
    () => {}
  );
}

hospitalEvents.on('patient:created', data =>
  audit('event_patient_created', data)
);

hospitalEvents.on('file:uploaded', data =>
  audit('event_file_uploaded', data)
);

// -------------------- MIDDLEWARE --------------------

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: false }));

app.use(session({
  name: 'medicore.sid',
  secret: process.env.SESSION_SECRET ||
    'local-development-secret-change-me',
  resave: false,
  saveUninitialized: false,
  store: process.env.NODE_ENV === 'production'
    ? MongoStore.create({
        mongoUrl: process.env.MONGODB_URI
      })
    : undefined,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 4 * 60 * 60 * 1000
  }
}));

app.use(express.static(path.join(__dirname, 'public')));

// -------------------- DATABASE MODELS --------------------

const { Schema } = mongoose;
const opts = { timestamps: true };

const patientSchema = new Schema({
  name: { type: String, required: true, trim: true },
  gender: {
    type: String,
    enum: ['Female', 'Male', 'Other'],
    required: true
  },
  dateOfBirth: { type: String, required: true },
  phone: { type: String, required: true, trim: true, unique: true },
  email: { type: String, trim: true, lowercase: true },
  address: String,
  bloodGroup: String
}, opts);

patientSchema.index({ name: 1 });

const doctorSchema = new Schema({
  name: { type: String, required: true },
  specialization: { type: String, required: true },
  department: { type: String, required: true },
  phone: String,
  availability: {
    type: [String],
    default: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri']
  },
  active: { type: Boolean, default: true }
}, opts);

const appointmentSchema = new Schema({
  patient: {
    type: Schema.Types.ObjectId,
    ref: 'Patient',
    required: true
  },
  doctor: {
    type: Schema.Types.ObjectId,
    ref: 'Doctor',
    required: true
  },
  date: { type: String, required: true },
  time: { type: String, required: true },
  reason: { type: String, required: true },
  status: {
    type: String,
    enum: ['SCHEDULED', 'COMPLETED', 'CANCELLED'],
    default: 'SCHEDULED'
  }
}, opts);

appointmentSchema.index({
  doctor: 1,
  date: 1,
  time: 1,
  status: 1
});

const prescriptionSchema = new Schema({
  patient: {
    type: Schema.Types.ObjectId,
    ref: 'Patient',
    required: true
  },
  doctor: {
    type: Schema.Types.ObjectId,
    ref: 'Doctor',
    required: true
  },
  appointment: {
    type: Schema.Types.ObjectId,
    ref: 'Appointment'
  },
  medicines: [{
    name: { type: String, required: true },
    dosage: String,
    frequency: String,
    duration: String
  }],
  notes: String,
  createdBy: String
}, opts);

const notificationSchema = new Schema({
  title: { type: String, required: true },
  message: { type: String, required: true },
  type: { type: String, default: 'info' },
  read: { type: Boolean, default: false }
}, opts);

const userSchema = new Schema({
  username: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  passwordHash: { type: String, required: true },
  role: {
    type: String,
    enum: ['Admin', 'Staff', 'Doctor'],
    default: 'Staff'
  },
  active: { type: Boolean, default: true }
}, opts);

const uploadSchema = new Schema({
  originalName: { type: String, required: true },
  storedName: { type: String, required: true },
  mimeType: { type: String, required: true },
  size: { type: Number, required: true },
  uploadedBy: { type: String, required: true }
}, opts);

const Patient = mongoose.model('Patient', patientSchema);
const Doctor = mongoose.model('Doctor', doctorSchema);
const Appointment = mongoose.model('Appointment', appointmentSchema);
const User = mongoose.model('User', userSchema);
const Prescription = mongoose.model('Prescription', prescriptionSchema);
const Notification = mongoose.model('Notification', notificationSchema);
const Upload = mongoose.model('Upload', uploadSchema);

// -------------------- FILE UPLOAD --------------------

const uploadStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) =>
    cb(null, randomUUID() + path.extname(file.originalname).toLowerCase())
});

const safeUpload = multer({
  storage: uploadStorage,
  limits: { fileSize: 5 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    const allowed = [
      'application/pdf',
      'image/png',
      'image/jpeg'
    ];

    if (allowed.includes(file.mimetype)) {
      return cb(null, true);
    }

    cb(new Error('Only PDF, PNG and JPG files are allowed.'));
  }
});

// -------------------- HELPER FUNCTIONS --------------------

const asyncHandler = fn => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

const loggedIn = (req, res, next) =>
  req.session.user
    ? next()
    : res.status(401).json({ error: 'Please log in first.' });

const adminOnly = (req, res, next) =>
  req.session.user?.role === 'Admin'
    ? next()
    : res.status(403).json({
        error: 'Administrator access required.'
      });

// -------------------- HEALTH AND SESSION --------------------

app.get('/api/health', (req, res) => {
  res.json({
    app: 'MediCore',
    database: mongoose.connection.readyState === 1
      ? 'connected'
      : 'disconnected',
    databaseName: mongoose.connection.name,
    patientCollection: Patient.collection.name
  });
});

app.get('/api/session', (req, res) => {
  res.json({ user: req.session.user || null });
});

// -------------------- LOGIN AND LOGOUT --------------------

app.post('/api/login', asyncHandler(async (req, res) => {
  const username = String(req.body.username || '').trim();
  const password = String(req.body.password || '');

  if (!username || !password) {
    return res.status(400).json({
      error: 'Enter both username and password.'
    });
  }

  const user = await User.findOne({ username, active: true });

  if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
    audit('login_failed', { username });
    return res.status(401).json({
      error: 'Incorrect username or password.'
    });
  }

  req.session.regenerate(err => {
    if (err) {
      return res.status(500).json({
        error: 'Could not start a session. Try again.'
      });
    }

    req.session.user = {
      id: String(user._id),
      username: user.username,
      role: user.role
    };

    req.session.save(saveErr => {
      if (saveErr) {
        return res.status(500).json({
          error: 'Could not save login session.'
        });
      }

      audit('login_success', {
        username,
        role: user.role
      });

      res.json({ user: req.session.user });
    });
  });
}));

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

// -------------------- DASHBOARD --------------------

app.get('/api/dashboard', loggedIn, asyncHandler(async (req, res) => {
  const [
    patients,
    doctors,
    appointments,
    scheduled,
    staff,
    prescriptions,
    unreadNotifications
  ] = await Promise.all([
    Patient.countDocuments(),
    Doctor.countDocuments({ active: true }),
    Appointment.countDocuments(),
    Appointment.countDocuments({ status: 'SCHEDULED' }),
    User.countDocuments({ role: 'Staff', active: true }),
    Prescription.countDocuments(),
    Notification.countDocuments({ read: false })
  ]);

  res.json({
    counts: {
      patients,
      doctors,
      appointments,
      scheduled,
      staff,
      prescriptions,
      unreadNotifications
    }
  });
}));

// -------------------- PATIENTS --------------------

// Get patients from MongoDB
app.get('/api/patients', loggedIn, asyncHandler(async (req, res) => {
  const q = String(req.query.q || '').trim();

  const filter = q
    ? {
        $or: [
          { name: { $regex: q, $options: 'i' } },
          { phone: { $regex: q, $options: 'i' } }
        ]
      }
    : {};

  const patients = await Patient.find(filter)
    .sort({ createdAt: -1 })
    .limit(300)
    .lean();

  console.log(
    `GET /api/patients: returned ${patients.length} record(s) from "${mongoose.connection.name}.${Patient.collection.name}"`
  );

  res.json(patients);
}));

// Create a patient and verify the saved record
app.post('/api/patients', loggedIn, asyncHandler(async (req, res) => {
  console.log('\n--- NEW PATIENT REQUEST ---');
  console.log('Request body:', req.body);
  console.log('Database:', mongoose.connection.name);
  console.log('Collection:', Patient.collection.name);

  const name = String(req.body.name || '').trim();
  const gender = String(req.body.gender || '').trim();
  const dateOfBirth = String(req.body.dateOfBirth || '').trim();
  const phone = String(req.body.phone || '').trim();
  const email = String(req.body.email || '').trim();
  const address = String(req.body.address || '').trim();
  const bloodGroup = String(req.body.bloodGroup || '').trim();

  if (!name || !gender || !dateOfBirth || !phone) {
    return res.status(400).json({
      success: false,
      error: 'Name, gender, date of birth and phone are required.',
      received: {
        name,
        gender,
        dateOfBirth,
        phone
      }
    });
  }

  try {
    const patient = await Patient.create({
      name,
      gender,
      dateOfBirth,
      phone,
      email: email || undefined,
      address,
      bloodGroup
    });

    console.log('Patient inserted successfully.');
    console.log('Patient ID:', String(patient._id));
    console.log('Patient name:', patient.name);

    // Read the new record back from the same MongoDB connection.
    const savedPatient = await Patient.findById(patient._id).lean();

    if (!savedPatient) {
      console.error('Insert returned an ID, but read-back failed.');

      return res.status(500).json({
        success: false,
        error: 'Patient insert could not be verified.'
      });
    }

    console.log('Verified saved patient:', {
      id: String(savedPatient._id),
      name: savedPatient.name,
      phone: savedPatient.phone
    });
    console.log('--- PATIENT SAVE COMPLETE ---\n');

    audit('patient_created', {
      id: String(savedPatient._id),
      by: req.session.user.username
    });

    hospitalEvents.emit('patient:created', {
      id: String(savedPatient._id),
      by: req.session.user.username
    });

    return res.status(201).json({
      success: true,
      message: 'Patient saved and verified in MongoDB.',
      database: mongoose.connection.name,
      collection: Patient.collection.name,
      patient: savedPatient
    });
  } catch (error) {
    console.error('PATIENT SAVE FAILED:', error);

    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        error: 'This phone number already exists. Use a unique phone number.'
      });
    }

    if (error.name === 'ValidationError') {
      return res.status(400).json({
        success: false,
        error: error.message
      });
    }

    throw error;
  }
}));

// -------------------- DOCTORS --------------------

app.get('/api/doctors', loggedIn, asyncHandler(async (req, res) => {
  res.json(
    await Doctor.find({ active: true })
      .sort({ name: 1 })
      .lean()
  );
}));

app.get('/api/availability', loggedIn, asyncHandler(async (req, res) => {
  res.json(
    await Doctor.find(
      { active: true },
      'name specialization availability'
    ).sort({ name: 1 }).lean()
  );
}));

// -------------------- APPOINTMENTS --------------------

app.get('/api/appointments', loggedIn, asyncHandler(async (req, res) => {
  const rows = await Appointment.find()
    .sort({ date: -1, time: -1 })
    .limit(300)
    .populate('patient', 'name phone')
    .populate('doctor', 'name specialization department');

  res.json(rows.map(a => ({
    _id: a._id,
    date: a.date,
    time: a.time,
    reason: a.reason,
    status: a.status,
    patientName: a.patient?.name || 'Unknown',
    doctorName: a.doctor?.name || 'Unknown'
  })));
}));

app.post('/api/appointments', loggedIn, asyncHandler(async (req, res) => {
  const { patientId, doctorId, date, time, reason } = req.body;

  if (![patientId, doctorId, date, time, reason]
    .every(v => String(v || '').trim())) {
    return res.status(400).json({
      error: 'Fill every appointment field.'
    });
  }

  if (
    !mongoose.isValidObjectId(patientId) ||
    !mongoose.isValidObjectId(doctorId)
  ) {
    return res.status(400).json({
      error: 'Select a valid patient and doctor.'
    });
  }

  const [patient, doctor] = await Promise.all([
    Patient.findById(patientId),
    Doctor.findOne({ _id: doctorId, active: true })
  ]);

  if (!patient || !doctor) {
    return res.status(400).json({
      error: 'The selected patient or doctor was not found.'
    });
  }

  const conflict = await Appointment.findOne({
    doctor: doctorId,
    date,
    time,
    status: 'SCHEDULED'
  });

  if (conflict) {
    return res.status(409).json({
      error: 'This doctor already has a scheduled appointment at that time.'
    });
  }

  const appointment = await Appointment.create({
    patient: patientId,
    doctor: doctorId,
    date,
    time,
    reason
  });

  audit('appointment_created', {
    id: String(appointment._id),
    by: req.session.user.username
  });

  await Notification.create({
    title: 'Appointment booked',
    message: `${patient.name} has an appointment with ${doctor.name} on ${date} at ${time}.`,
    type: 'appointment'
  });

  res.status(201).json({
    message: 'Appointment saved to MongoDB.',
    appointment
  });
}));

app.patch('/api/appointments/:id', loggedIn, asyncHandler(async (req, res) => {
  if (!['SCHEDULED', 'COMPLETED', 'CANCELLED'].includes(req.body.status)) {
    return res.status(400).json({
      error: 'Choose a valid status.'
    });
  }

  if (!mongoose.isValidObjectId(req.params.id)) {
    return res.status(400).json({
      error: 'Invalid appointment ID.'
    });
  }

  const a = await Appointment.findByIdAndUpdate(
    req.params.id,
    { status: req.body.status },
    { new: true, runValidators: true }
  );

  if (!a) {
    return res.status(404).json({
      error: 'Appointment not found.'
    });
  }

  res.json({ message: 'Appointment updated in MongoDB.' });
}));

// -------------------- STAFF --------------------

app.get('/api/staff', loggedIn, adminOnly, asyncHandler(async (req, res) => {
  res.json(
    await User.find(
      { role: { $in: ['Staff', 'Doctor'] } },
      'username role active createdAt'
    ).sort({ username: 1 }).lean()
  );
}));

app.post('/api/staff', loggedIn, adminOnly, asyncHandler(async (req, res) => {
  const username = String(req.body.username || '').trim();
  const password = String(req.body.password || '');
  const role = String(req.body.role || 'Staff');

  if (!username || password.length < 8) {
    return res.status(400).json({
      error: 'Enter a username and a password of at least 8 characters.'
    });
  }

  if (!['Staff', 'Doctor'].includes(role)) {
    return res.status(400).json({
      error: 'Role must be Staff or Doctor.'
    });
  }

  const user = await User.create({
    username,
    passwordHash: await bcrypt.hash(password, 12),
    role
  });

  audit('staff_created', {
    username,
    role,
    by: req.session.user.username
  });

  res.status(201).json({
    message: 'Staff account saved to MongoDB.',
    staff: {
      _id: user._id,
      username: user.username,
      role: user.role,
      active: user.active
    }
  });
}));

app.patch('/api/staff/:id', loggedIn, adminOnly, asyncHandler(async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) {
    return res.status(400).json({
      error: 'Invalid staff ID.'
    });
  }

  const user = await User.findOneAndUpdate(
    {
      _id: req.params.id,
      role: { $in: ['Staff', 'Doctor'] }
    },
    { active: Boolean(req.body.active) },
    { new: true }
  );

  if (!user) {
    return res.status(404).json({
      error: 'Staff account not found.'
    });
  }

  res.json({
    message: `Account ${user.active ? 'activated' : 'deactivated'}.`
  });
}));

// -------------------- PRESCRIPTIONS --------------------

app.get('/api/prescriptions', loggedIn, asyncHandler(async (req, res) => {
  const rows = await Prescription.find()
    .sort({ createdAt: -1 })
    .limit(300)
    .populate('patient', 'name')
    .populate('doctor', 'name');

  res.json(rows.map(p => ({
    _id: p._id,
    patientName: p.patient?.name || 'Unknown',
    doctorName: p.doctor?.name || 'Unknown',
    medicines: p.medicines,
    notes: p.notes,
    createdAt: p.createdAt
  })));
}));

app.post('/api/prescriptions', loggedIn, asyncHandler(async (req, res) => {
  const {
    patientId,
    doctorId,
    medicine,
    dosage,
    frequency,
    duration,
    notes
  } = req.body;

  if (![patientId, doctorId, medicine]
    .every(v => String(v || '').trim())) {
    return res.status(400).json({
      error: 'Patient, doctor and medicine are required.'
    });
  }

  if (
    !mongoose.isValidObjectId(patientId) ||
    !mongoose.isValidObjectId(doctorId)
  ) {
    return res.status(400).json({
      error: 'Select a valid patient and doctor.'
    });
  }

  const [patient, doctor] = await Promise.all([
    Patient.findById(patientId),
    Doctor.findOne({ _id: doctorId, active: true })
  ]);

  if (!patient || !doctor) {
    return res.status(400).json({
      error: 'Selected patient or doctor was not found.'
    });
  }

  const prescription = await Prescription.create({
    patient: patientId,
    doctor: doctorId,
    medicines: [{ name: medicine, dosage, frequency, duration }],
    notes,
    createdBy: req.session.user.username
  });

  await Notification.create({
    title: 'Prescription created',
    message: `A prescription was created for ${patient.name} by ${doctor.name}.`,
    type: 'prescription'
  });

  res.status(201).json({
    message: 'Prescription saved to MongoDB.',
    prescription
  });
}));

// -------------------- UPLOADS --------------------

app.get('/api/uploads', loggedIn, asyncHandler(async (req, res) => {
  res.json(
    await Upload.find()
      .select('-storedName')
      .sort({ createdAt: -1 })
      .limit(100)
      .lean()
  );
}));

app.post(
  '/api/uploads',
  loggedIn,
  (req, res, next) => {
    safeUpload.single('document')(req, res, err => {
      if (err) {
        return res.status(400).json({ error: err.message });
      }
      next();
    });
  },
  asyncHandler(async (req, res) => {
    if (!req.file) {
      return res.status(400).json({
        error: 'Choose a PDF, PNG or JPG file.'
      });
    }

    const item = await Upload.create({
      originalName: path.basename(req.file.originalname).slice(0, 180),
      storedName: req.file.filename,
      mimeType: req.file.mimetype,
      size: req.file.size,
      uploadedBy: req.session.user.username
    });

    hospitalEvents.emit('file:uploaded', {
      id: String(item._id),
      by: req.session.user.username,
      name: item.originalName
    });

    res.status(201).json({
      message: 'File uploaded; metadata saved in MongoDB.',
      file: {
        _id: item._id,
        originalName: item.originalName,
        mimeType: item.mimeType,
        size: item.size,
        createdAt: item.createdAt
      }
    });
  })
);

// -------------------- URL LAB --------------------

app.get('/api/lab/url-info', loggedIn, (req, res) => {
  const parsed = new URL(
    req.originalUrl,
    `http://${req.headers.host || 'localhost'}`
  );

  res.json({
    pathname: parsed.pathname,
    queryParameters: Object.fromEntries(parsed.searchParams.entries())
  });
});

// -------------------- NOTIFICATIONS --------------------

app.get('/api/notifications', loggedIn, asyncHandler(async (req, res) => {
  res.json(
    await Notification.find()
      .sort({ createdAt: -1 })
      .limit(50)
      .lean()
  );
}));

app.patch('/api/notifications/:id/read', loggedIn, asyncHandler(async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) {
    return res.status(400).json({
      error: 'Invalid notification ID.'
    });
  }

  const item = await Notification.findByIdAndUpdate(
    req.params.id,
    { read: true },
    { new: true }
  );

  if (!item) {
    return res.status(404).json({
      error: 'Notification not found.'
    });
  }

  res.json({ message: 'Notification marked as read.' });
}));

// -------------------- REPORTS --------------------

app.get('/api/reports/summary', loggedIn, asyncHandler(async (req, res) => {
  const [
    patients,
    doctors,
    staff,
    appointments,
    prescriptions,
    byStatus
  ] = await Promise.all([
    Patient.countDocuments(),
    Doctor.countDocuments({ active: true }),
    User.countDocuments({ role: 'Staff', active: true }),
    Appointment.countDocuments(),
    Prescription.countDocuments(),
    Appointment.aggregate([
      { $group: { _id: '$status', total: { $sum: 1 } } },
      { $sort: { _id: 1 } }
    ])
  ]);

  res.json({
    patients,
    doctors,
    staff,
    appointments,
    prescriptions,
    byStatus
  });
}));

app.get('/api/reports/appointments-by-status', loggedIn, asyncHandler(async (req, res) => {
  res.json(
    await Appointment.aggregate([
      { $group: { _id: '$status', total: { $sum: 1 } } },
      { $sort: { _id: 1 } }
    ])
  );
}));

app.get('/api/backup', loggedIn, adminOnly, asyncHandler(async (req, res) => {
  const [
    patients,
    doctors,
    appointments,
    users,
    prescriptions,
    notifications
  ] = await Promise.all([
    Patient.find().lean(),
    Doctor.find().lean(),
    Appointment.find().lean(),
    User.find({}, '-passwordHash').lean(),
    Prescription.find().lean(),
    Notification.find().lean()
  ]);

  audit('backup_exported', {
    by: req.session.user.username
  });

  res.setHeader(
    'Content-Disposition',
    `attachment; filename=medicore-backup-${new Date().toISOString().slice(0, 10)}.json`
  );

  res.json({
    exportedAt: new Date().toISOString(),
    database: mongoose.connection.name,
    patients,
    doctors,
    appointments,
    users,
    prescriptions,
    notifications
  });
}));

// -------------------- API 404 AND ERROR HANDLING --------------------

app.use('/api', (_req, res) => {
  res.status(404).json({ error: 'API route not found.' });
});

app.use((err, req, res, next) => {
  console.error('SERVER ERROR:', err);

  audit('error', {
    message: err.message,
    path: req.path
  });

  if (res.headersSent) {
    return next(err);
  }

  if (err.code === 11000) {
    return res.status(409).json({
      success: false,
      error: 'That phone number or username already exists.'
    });
  }

  if (
    err.name === 'ValidationError' ||
    err.name === 'CastError'
  ) {
    return res.status(400).json({
      success: false,
      error: err.message
    });
  }

  res.status(500).json({
    success: false,
    error: process.env.NODE_ENV === 'production'
      ? 'Unexpected server error.'
      : err.message
  });
});

// -------------------- DEMO DATA --------------------

async function seedDemoData() {
  const username = process.env.DEMO_ADMIN_USERNAME || 'admin';

  if (!(await User.exists({ username }))) {
    await User.create({
      username,
      passwordHash: await bcrypt.hash(
        process.env.DEMO_ADMIN_PASSWORD || 'MediCoreDemo@123',
        12
      ),
      role: 'Admin'
    });
  }

  if (!(await Doctor.countDocuments())) {
    await Doctor.insertMany([
      {
        name: 'Dr. Ananya Sharma',
        specialization: 'Cardiology',
        department: 'Cardiology',
        phone: '9000000001'
      },
      {
        name: 'Dr. Rahul Mehta',
        specialization: 'General Medicine',
        department: 'General Medicine',
        phone: '9000000002'
      },
      {
        name: 'Dr. Neha Das',
        specialization: 'Pediatrics',
        department: 'Pediatrics',
        phone: '9000000003'
      }
    ]);
  }
}

// -------------------- START SERVER --------------------

async function start() {
  const mongoUri =
    process.env.MONGODB_URI ||
    'mongodb://127.0.0.1:27017/medicore_hospital';

  // Helpful database connection diagnostics
  mongoose.connection.on('error', err => {
    console.error('MongoDB connection error:', err.message);
  });

  mongoose.connection.on('disconnected', () => {
    console.error('MongoDB disconnected.');
  });

  await mongoose.connect(mongoUri);

  console.log('-----------------------------------');
  console.log('MongoDB connected successfully.');
  console.log('Database:', mongoose.connection.name);
  console.log('Patient collection:', Patient.collection.name);
  console.log('MongoDB host:', mongoose.connection.host);
  console.log('-----------------------------------');

  if (process.env.SEED_DEMO === 'true') {
    await seedDemoData();
  }

  await Doctor.updateMany(
    { availability: { $exists: false } },
    {
      $set: {
        availability: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri']
      }
    }
  );

  // Ensure collections exist at startup
  for (const model of [
    Patient,
    Doctor,
    Appointment,
    User,
    Prescription,
    Notification,
    Upload
  ]) {
    try {
      await model.createCollection();
    } catch (err) {
      if (
        err.codeName !== 'NamespaceExists' &&
        err.code !== 48
      ) {
        throw err;
      }
    }
  }

  app.listen(PORT, () => {
    console.log(`MediCore running at http://localhost:${PORT}`);
  });
}

start().catch(err => {
  console.error('Application startup failed:', err.message);
  process.exit(1);
});
