# MediCore syllabus-to-project mapping

This project is the web-stack conversion of the original Java Swing + MySQL MediCore. It uses **HTML/CSS/JavaScript + Node.js/Express + MongoDB/Mongoose**. It does not use Java/JDBC/MySQL for the web app.

| Syllabus concept | Where to demonstrate it |
|---|---|
| Semantic HTML (`header`, `section`, `article`, `footer`) | `public/index.html`, `public/lab-tools.html` |
| HTML forms, native validation | Login, patient, appointment, prescription, staff and upload forms; `required`, `type`, `minlength`, `accept` |
| CSS selectors, box model, Grid/Flexbox, responsive media queries | `public/styles.css`; inspect the responsive layout by resizing browser DevTools |
| JavaScript DOM, events, RegExp/validation, safe rendering | `public/app.js`; uses event listeners, DOM updates and `textContent` for user-provided values |
| Node.js HTTP / routing | `server.js`, Express `/api/...` routes |
| Node File System | `server.js` creates `logs/` and `uploads/`, writes audit events; uploaded file bytes are stored locally |
| Node Events | `EventEmitter` events `patient:created` and `file:uploaded` append audit entries |
| URL module | `/api/lab/url-info?module=url` parses the URL using Node's built-in `URL` class |
| File uploads | Open `http://localhost:3000/lab-tools.html` after signing in; PDF/PNG/JPG, 5 MB limit |
| Email automation | `scripts/send-email.js` using Nodemailer and SMTP environment variables (optional, needs a real SMTP account/app password) |
| MongoDB CRUD and modeling | Mongoose models: patients, doctors, appointments, users, prescriptions, notifications, uploads |
| Relational logic in NoSQL | Appointment and prescription documents store ObjectId references to patients/doctors; `populate()` resolves names |
| Indexes | Unique patient phone and username, patient name, appointment doctor/date/time/status |
| Aggregation | `/api/reports/summary` and `/api/reports/appointments-by-status` use `$group` and `$sum` |
| MongoDB Atlas | Configure `MONGODB_URI` in `.env` with your Atlas URI |
| Git / CI | `.gitignore`, `.github/workflows/ci.yml`; run `git init`, commit, push to GitHub |
| Jenkins | `Jenkinsfile` demonstrates install, syntax check and tests. Configure a Jenkins NodeJS tool named `NodeJS20`; on Linux change `bat` steps to `sh` |
| Deployment | `Dockerfile` and `docker-compose.yml` for local app + MongoDB. Render can host the Node backend; use Atlas for persistent cloud DB |

## Important platform note

**Tomcat is for Java/JSP/Servlet applications, not this Node.js/Express server.** For this converted version, run the Node backend directly or deploy it to Render. If your instructor requires a Tomcat demonstration specifically, use the original Java/JSP experiment separately; do not claim the Node server runs on Tomcat.

## Demo safety

Use synthetic data only. This is a student demonstration, not a production clinical system. Uploads are stored on local disk and are not a secure medical-document vault. Set a strong `SESSION_SECRET`, change the demo password, configure HTTPS, and do not publish `.env` or real patient information.
