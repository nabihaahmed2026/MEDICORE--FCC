# MediCore Health Management System — MongoDB Full-Stack Mini Project

This version opens with a **username/password login page**. The hospital site remains hidden until the server verifies the credentials and creates a session. Patient registrations, doctor selection, appointment bookings and appointment status updates are saved to/read from MongoDB through the Node.js/Express API.

## Stack and course concepts
- HTML5 forms and semantic page layout
- CSS responsive design, Flexbox/Grid
- JavaScript DOM events, form handling, `fetch()` HTTP requests
- Node.js + Express REST API, validation, sessions, logging
- MongoDB database/collections via Mongoose schemas
- CRUD: patient create/read, appointment create/read/update
- Referenced documents: appointments reference patient and doctor ObjectIds
- Indexes: unique patient phone, patient name, doctor/date/time/status
- Aggregation pipeline: appointment totals grouped by status (`/api/reports/appointments-by-status`)
- MongoDB Atlas connection string support
- Docker Compose for a repeatable local demo; basic tests

## Quickest setup (recommended): Docker
Install Docker Desktop for Windows and ensure it is running. Extract the ZIP. Open PowerShell in the extracted `medicore-fullstack-mongodb` folder and run:

```powershell
docker compose up --build
```

Wait until the app says it is running, then open **http://localhost:3000**. Docker starts both the Node app and MongoDB and connects them automatically.

Demo login:
- Username: `admin`
- Password: `MediCoreDemo@123`

After login, register a patient under **Patients**. The form sends the data to the Express API, which inserts a document in MongoDB. Then create an appointment under **Appointments**; it references the patient and doctor document IDs. Refresh the list or dashboard to see the saved data.

Stop the services with `Ctrl+C`, or run `docker compose down` in another terminal. To delete the local Docker demo database permanently, use `docker compose down -v` (this deletes its saved data).

## Option B: MongoDB Community Server installed on Windows
1. Install **MongoDB Community Server**. During installation, keep MongoDB running as a Windows service. Optionally install **MongoDB Compass** for a visual database browser.
2. Install **Node.js 20 or newer**.
3. Extract the ZIP and open PowerShell in the project folder.
4. Create your environment file:

```powershell
Copy-Item .env.example .env
```

5. Open `.env` in Notepad. For local MongoDB, use:

```text
MONGODB_URI=mongodb://127.0.0.1:27017/medicore_hospital
SEED_DEMO=true
DEMO_ADMIN_USERNAME=admin
DEMO_ADMIN_PASSWORD=MediCoreDemo@123
```

Keep the `MONGODB_URI` as above if MongoDB Community Server is running locally. The database `medicore_hospital` and collections are created automatically when the app first writes data.
6. Install dependencies and start the app:

```powershell
npm install
npm start
```

7. Visit **http://localhost:3000** and sign in with the demo credentials above.

If startup says it cannot connect, check Windows Services for `MongoDB Server`, or open MongoDB Compass and connect to `mongodb://127.0.0.1:27017`.

## Option C: MongoDB Atlas cloud database settings
1. Go to **https://www.mongodb.com/atlas** and sign in/create an account.
2. Create a project and a free cluster if the free option is available to your account/region.
3. In **Database Access**, create a database user with a username and password. This is a *database user*, not your Atlas website login.
4. In **Network Access**, add your current IP address. Avoid `0.0.0.0/0` except for a temporary, carefully controlled classroom test; it allows connection attempts from anywhere.
5. Open your cluster and select **Connect → Drivers → Node.js**. Copy the connection string. It usually resembles:

```text
mongodb+srv://DB_USER:DB_PASSWORD@cluster-name.xxxxx.mongodb.net/medicore_hospital?retryWrites=true&w=majority
```

6. In your project's `.env`, replace the local `MONGODB_URI` with the Atlas connection string. Replace `DB_USER`, `DB_PASSWORD`, and the cluster host with your actual values. URL-encode special characters in the database password. Do not include angle brackets.
7. Keep `SEED_DEMO=true` for the first run so the demo admin account and sample doctors are created. Change the demo password before any real/public deployment. Do not share `.env` or commit it to GitHub.
8. Run `npm start`, then visit `http://localhost:3000`. The API health endpoint at `http://localhost:3000/api/health` should report `"database":"connected"`.

Example `.env` layout (do not paste placeholder credentials unchanged):

```text
PORT=3000
NODE_ENV=development
SESSION_SECRET=put-a-long-random-secret-here
MONGODB_URI=mongodb+srv://YOUR_DB_USER:YOUR_URL_ENCODED_PASSWORD@YOUR_CLUSTER.mongodb.net/medicore_hospital?retryWrites=true&w=majority
SEED_DEMO=true
DEMO_ADMIN_USERNAME=admin
DEMO_ADMIN_PASSWORD=choose-a-strong-demo-password
```

## Verify database data
With **MongoDB Compass**, connect using the same URI. Open the `medicore_hospital` database and the `patients`, `doctors`, `appointments`, and `users` collections. Register a patient in the site and refresh the `patients` collection in Compass; the new document should appear.

Or with `mongosh`, run:

```javascript
use medicore_hospital
db.patients.find().pretty()
db.doctors.find().pretty()
db.appointments.find().pretty()
db.appointments.aggregate([{ $group: { _id: "$status", total: { $sum: 1 } } }])
```

The actual collection names are created by Mongoose from the model names (lowercase plural forms).

## Important login/database behavior
- The initial page is the login form. The server validates the username and bcrypt password hash against the MongoDB `users` collection.
- The hospital interface is displayed only after successful login. API endpoints for patients, doctors, appointments and dashboard require an authenticated session.
- Passwords are never stored as plain text; the seed account's password is bcrypt-hashed.
- For local demo, default credentials are intentionally simple. Change them for any shared deployment.
- This is an academic demonstration and should use synthetic data only, not real patient medical records.

## Useful routes
- `GET /api/health` — MongoDB connection health
- `POST /api/login`, `POST /api/logout`, `GET /api/session` — authentication/session
- `GET /api/dashboard` — totals
- `GET/POST /api/patients` — search/list and create patient
- `GET /api/doctors` — doctor directory
- `GET/POST /api/appointments` — list and create appointments
- `PATCH /api/appointments/:id` — update appointment status
- `GET /api/reports/appointments-by-status` — MongoDB aggregation report

## Extra syllabus demonstrations
- Open `http://localhost:3000/lab-tools.html` after signing in to test file upload and the Node URL module route. Files are limited to PDF/PNG/JPG and 5 MB; metadata is saved in MongoDB and the file is saved in the local `uploads/` folder.
- Optional email automation: configure SMTP values in `.env`, then run `npm run email:test`. Use an app password where your provider requires it. Never commit SMTP credentials.
- See `docs/SYLLABUS_CONCEPT_MAPPING.md` for a full lab-topic-to-file mapping.

## Files
- `server.js` — Express API, Mongoose models, authentication and database connection
- `public/index.html` — login screen and authenticated hospital UI
- `public/app.js` — login flow and frontend-to-database API calls
- `public/styles.css` — styling
- `.env.example` — database connection settings template
- `docker-compose.yml` — local app + MongoDB setup


## Updated MediCore features

This build includes:
- Dashboard counts for patients, active doctors, appointments, scheduled visits, staff, prescriptions, and unread notifications.
- Patient registration and searchable patient records.
- Appointment booking with conflict checks and status updates.
- Doctor directory with listed availability days.
- Administrator-only staff/doctor login account creation and activation controls. Passwords are stored as bcrypt hashes.
- Prescription records, in-app appointment/prescription notifications, and appointment status reports.
- Administrator-only JSON backup export (password hashes are excluded). Treat exported patient information as sensitive.
- MongoDB collections are initialized at application startup so they appear in Compass before the first record is added. Expected database: `medicore_hospital`; collections include `patients`, `doctors`, `appointments`, `users`, `prescriptions`, and `notifications`.
- The app asks users to sign in again after a page reload/reopen, rather than silently reusing an active UI session.

### Run locally
1. Copy `.env.example` to `.env` in the project folder.
2. Keep each environment setting on its own line and check `MONGODB_URI=mongodb://127.0.0.1:27017/medicore_hospital` and `SEED_DEMO=true`.
3. Run `npm install`, then `npm start` from inside `medicore-fullstack-mongodb`.
4. If port 3000 is already in use, stop the other MediCore/Node process before starting another copy.
5. Open `http://localhost:3000`. The default local demo account is `admin` / `MediCoreDemo@123`; change demo credentials before any real deployment.

**Safety note:** This is an academic/demo application, not a certified clinical system. Do not use real patient information or rely on it for clinical decisions without a proper security, privacy, access-control, and clinical validation review.
