require('dotenv').config();
const nodemailer = require('nodemailer');

async function main() {
  const { SMTP_HOST, SMTP_PORT, SMTP_SECURE, SMTP_USER, SMTP_PASS, MAIL_TO } = process.env;
  if (![SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, MAIL_TO].every(Boolean)) {
    throw new Error('Configure SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS and MAIL_TO in .env first.');
  }
  const transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT),
    secure: String(SMTP_SECURE).toLowerCase() === 'true',
    auth: { user: SMTP_USER, pass: SMTP_PASS }
  });
  await transporter.sendMail({
    from: SMTP_USER,
    to: MAIL_TO,
    subject: 'MediCore email automation test',
    text: `Hello,\n\nThis is an automated test email from the MediCore academic project.\nSent at: ${new Date().toISOString()}\n`
  });
  console.log(`Test email sent to ${MAIL_TO}`);
}
main().catch(err => { console.error('Email failed:', err.message); process.exitCode = 1; });
